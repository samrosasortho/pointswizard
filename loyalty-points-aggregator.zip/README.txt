# Loyalty Points Aggregator (Manual + AI + Award Estimator)

A single-file web app. Open `index.html` locally or host on GitHub Pages / Glitch.

## GitHub Pages
1. Create a new public repo (e.g., `loyalty-points-aggregator`).
2. Upload `index.html`.
3. Settings → Pages → Branch: `main` / root → Save.
4. Your site will appear at `https://<your-username>.github.io/loyalty-points-aggregator/`.

## Glitch
1. Go to glitch.com → New Project → Hello-webpage.
2. Replace their `index.html` with this one.
3. Your live URL appears at the top-left (updates on save).
